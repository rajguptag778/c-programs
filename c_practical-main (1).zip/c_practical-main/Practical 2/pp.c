#include<stdio.h>
int main(int argc, char const *argv[])
{
    int a,b,c;
    a=b=
    return 0;
}
