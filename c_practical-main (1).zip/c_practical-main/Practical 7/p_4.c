#include<stdio.h>
// 4.	Write a function named GetMax, that will find the maximum among array of numbers.





int main(int argc, char const *argv[])
{
        

    return 0;
}
